'use strict';
'require view';
'require form';
'require uci';
'require ui';
'require rpc';
'require poll';
'require dom';

var callTestConnection = rpc.declare({
	object: 'luci.saturn',
	method: 'test_connection',
	params: ['type', 'host', 'port', 'endpoint_path'],
	expect: { '': {} }
});

var callGetStatus = rpc.declare({
	object: 'luci.saturn',
	method: 'get_status',
	expect: { '': {} }
});

var callUninstall = rpc.declare({
	object: 'luci.saturn',
	method: 'uninstall',
	expect: { '': {} }
});

var callStart = rpc.declare({
	object: 'luci.saturn',
	method: 'start',
	expect: { '': {} }
});

var callStop = rpc.declare({
	object: 'luci.saturn',
	method: 'stop',
	expect: { '': {} }
});

var callRestart = rpc.declare({
	object: 'luci.saturn',
	method: 'restart',
	expect: { '': {} }
});

var callGetRunningStatus = rpc.declare({
	object: 'luci.saturn',
	method: 'get_running_status',
	expect: { '': {} }
});

var callGetLogs = rpc.declare({
	object: 'luci.saturn',
	method: 'get_logs',
	params: ['lines'],
	expect: { '': {} }
});

var statusData = {};
var runningStatus = { running: false, process_count: 0 };

function getStatusBadge(health, enabled) {
	if (!enabled) {
		return E('span', { 'class': 'badge', 'style': 'background-color:#6c757d;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, 'DISABLED');
	}
	switch (health) {
		case 'healthy':
			return E('span', { 'class': 'badge', 'style': 'background-color:#28a745;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, '● UP');
		case 'unreachable':
			return E('span', { 'class': 'badge', 'style': 'background-color:#dc3545;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, '● DOWN');
		case 'disabled':
			return E('span', { 'class': 'badge', 'style': 'background-color:#6c757d;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, 'DISABLED');
		case 'unknown':
			return E('span', { 'class': 'badge', 'style': 'background-color:#ffc107;color:black;padding:2px 8px;border-radius:4px;font-size:11px;' }, '? UNKNOWN');
		default:
			if (health && health.startsWith('error:')) {
				return E('span', { 'class': 'badge', 'style': 'background-color:#fd7e14;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, '● ERR ' + health.split(':')[1]);
			}
			return E('span', { 'class': 'badge', 'style': 'background-color:#6c757d;color:white;padding:2px 8px;border-radius:4px;font-size:11px;' }, '...');
	}
}

function updateRunningStatusIndicator() {
	return callGetRunningStatus().then(function(result) {
		if (result) {
			runningStatus = result;
			var badge = document.getElementById('saturn-running-badge');
			if (badge) {
				if (result.running) {
					badge.style.backgroundColor = '#28a745';
					badge.textContent = 'RUNNING (' + result.process_count + ' process' + (result.process_count > 1 ? 'es' : '') + ')';
				} else {
					badge.style.backgroundColor = '#dc3545';
					badge.textContent = 'STOPPED';
				}
			}
		}
	}).catch(function(err) {
		console.error('Failed to get running status:', err);
	});
}

function updateStatusIndicators() {
	return Promise.all([
		callGetStatus().then(function(result) {
			if (result && result.services) {
				result.services.forEach(function(svc) {
					statusData[svc.section] = svc;
					var container = document.getElementById('saturn-status-' + svc.section);
					if (container) {
						dom.content(container, getStatusBadge(svc.health, svc.enabled));
					}
				});
			}
		}),
		updateRunningStatusIndicator()
	]).catch(function(err) {
		console.error('Failed to get status:', err);
	});
}

return view.extend({
	load: function() {
		return Promise.all([
			uci.load('saturn'),
			callGetStatus().then(function(result) {
				if (result && result.services) {
					result.services.forEach(function(svc) {
						statusData[svc.section] = svc;
					});
				}
			}).catch(function() {}),
			callGetRunningStatus().then(function(result) {
				if (result) {
					runningStatus = result;
				}
			}).catch(function() {})
		]);
	},

	render: function() {
		var m, s, o;

		m = new form.Map('saturn', _('Saturn - Network AI Services'),
			_('Configure AI services for zero-config network discovery. ' +
			  'Each service is advertised via mDNS for automatic client discovery.'));

		// Global settings section (maps to 'config saturn main')
		s = m.section(form.NamedSection, 'main', 'saturn', _('Global Settings'));

		o = s.option(form.Flag, 'enabled', _('Enable Saturn'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'health_interval', _('Health Check Interval'),
			_('Interval in seconds for health checking all services.'));
		o.datatype = 'uinteger';
		o.default = '30';
		o.placeholder = '30';

		o = s.option(form.Value, 'mdns_base_port', _('mDNS Base Port'),
			_('Base port for mDNS advertisement. Cloud services auto-increment from this. Network services use their backend port.'));
		o.datatype = 'port';
		o.default = '8400';
		o.placeholder = '8400';

		// Service control section (added to the form render output)
		var serviceControlHtml = E('div', { 'class': 'cbi-section', 'style': 'margin-bottom: 1em;' }, [
			E('h3', {}, _('Service Control')),
			E('div', { 'style': 'display: flex; align-items: center; gap: 1em; flex-wrap: wrap;' }, [
				E('span', { 'style': 'font-weight: bold;' }, _('Status: ')),
				E('span', {
					'id': 'saturn-running-badge',
					'style': 'background-color:' + (runningStatus.running ? '#28a745' : '#dc3545') + ';color:white;padding:4px 12px;border-radius:4px;font-size:12px;font-weight:bold;'
				}, runningStatus.running ? 'RUNNING (' + runningStatus.process_count + ' process' + (runningStatus.process_count > 1 ? 'es' : '') + ')' : 'STOPPED'),
				E('div', { 'style': 'display: flex; gap: 0.5em;' }, [
					E('button', {
						'class': 'btn cbi-button',
						'id': 'saturn-start-btn',
						'style': 'background-color:#28a745;color:white;border-color:#28a745;',
						'click': function(ev) {
							var btn = ev.target;
							btn.disabled = true;
							btn.textContent = _('Starting...');
							callStart().then(function(result) {
								btn.disabled = false;
								btn.textContent = _('Start');
								if (result.success) {
									ui.addNotification(null, E('p', result.message), 'info');
									updateRunningStatusIndicator();
								} else {
									ui.addNotification(null, E('p', [
										E('strong', _('Error: ')),
										result.error || _('Start failed')
									]), 'error');
								}
							}).catch(function(err) {
								btn.disabled = false;
								btn.textContent = _('Start');
								ui.addNotification(null, E('p', err.message || _('RPC failed')), 'error');
							});
						}
					}, _('Start')),
					E('button', {
						'class': 'btn cbi-button',
						'id': 'saturn-stop-btn',
						'style': 'background-color:#6c757d;color:white;border-color:#6c757d;',
						'click': function(ev) {
							var btn = ev.target;
							btn.disabled = true;
							btn.textContent = _('Stopping...');
							callStop().then(function(result) {
								btn.disabled = false;
								btn.textContent = _('Stop');
								if (result.success) {
									ui.addNotification(null, E('p', result.message), 'info');
									updateRunningStatusIndicator();
								} else {
									ui.addNotification(null, E('p', [
										E('strong', _('Error: ')),
										result.error || _('Stop failed')
									]), 'error');
								}
							}).catch(function(err) {
								btn.disabled = false;
								btn.textContent = _('Stop');
								ui.addNotification(null, E('p', err.message || _('RPC failed')), 'error');
							});
						}
					}, _('Stop')),
					E('button', {
						'class': 'btn cbi-button',
						'id': 'saturn-restart-btn',
						'style': 'background-color:#007bff;color:white;border-color:#007bff;',
						'click': function(ev) {
							var btn = ev.target;
							btn.disabled = true;
							btn.textContent = _('Restarting...');
							callRestart().then(function(result) {
								btn.disabled = false;
								btn.textContent = _('Restart');
								if (result.success) {
									ui.addNotification(null, E('p', result.message), 'info');
									updateRunningStatusIndicator();
								} else {
									ui.addNotification(null, E('p', [
										E('strong', _('Error: ')),
										result.error || _('Restart failed')
									]), 'error');
								}
							}).catch(function(err) {
								btn.disabled = false;
								btn.textContent = _('Restart');
								ui.addNotification(null, E('p', err.message || _('RPC failed')), 'error');
							});
						}
					}, _('Restart'))
				])
			]),
			E('p', { 'style': 'color: #666; margin-top: 0.5em; font-size: 12px;' },
				_('Start/Stop controls the saturn-beacon process. Changes to service configuration require Save & Apply followed by Restart.'))
		]);

		// Services section (maps to 'config service')
		s = m.section(form.TypedSection, 'service', _('Services'),
			_('Add AI services to advertise on the network. Lower priority numbers are preferred by clients. ' +
			  'Status refreshes automatically every 10 seconds.'));
		s.addremove = true;
		s.anonymous = true;
		s.addbtntitle = _('Add new service');

		// Status indicator (read-only, first column)
		o = s.option(form.DummyValue, '_status', _('Status'));
		o.rawhtml = true;
		o.cfgvalue = function(section_id) {
			var svc = statusData[section_id];
			var health = svc ? svc.health : 'unknown';
			var enabled = svc ? svc.enabled : (uci.get('saturn', section_id, 'enabled') === '1');
			return '<span id="saturn-status-' + section_id + '">' +
				(getStatusBadge(health, enabled)).outerHTML + '</span>';
		};

		// Service name
		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;
		o.placeholder = 'my-service';
		o.validate = function(section_id, value) {
			if (!/^[a-zA-Z0-9_-]+$/.test(value))
				return _('Name must contain only letters, numbers, hyphens and underscores');
			return true;
		};

		// Service type dropdown
		o = s.option(form.ListValue, 'type', _('Type'));
		o.value('openrouter', _('OpenRouter (cloud)'));
		o.value('anthropic', _('Anthropic (cloud)'));
		o.value('deepinfra', _('DeepInfra (cloud)'));
		o.value('ollama', _('Ollama (network)'));
		o.value('vllm', _('vLLM (network)'));
		o.value('localai', _('LocalAI (network)'));
		o.value('custom', _('Custom endpoint (network)'));
		o.rmempty = false;

		// Enabled flag
		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		// Priority (global across all services)
		o = s.option(form.Value, 'priority', _('Priority'),
			_('Lower number = higher priority. Used for client service selection.'));
		o.datatype = 'range(0,100)';
		o.default = '10';
		o.placeholder = '10';

		// --- Cloud service fields ---

		// API Key (for all cloud services)
		o = s.option(form.Value, 'api_key', _('API Key'),
			_('Your API key for the selected service.'));
		o.password = true;
		o.depends('type', 'openrouter');
		o.depends('type', 'anthropic');
		o.depends('type', 'deepinfra');
		o.rmempty = true;

		// Spending limit (OpenRouter only)
		o = s.option(form.Value, 'spending_limit', _('Spending Limit'),
			_('USD per ephemeral key. Set to 0 for no limit.'));
		o.datatype = 'ufloat';
		o.default = '0';
		o.placeholder = '0';
		o.depends('type', 'openrouter');

		// Rotation interval (OpenRouter, DeepInfra)
		o = s.option(form.Value, 'rotation_interval', _('Rotation Interval'),
			_('Credential rotation interval in seconds. Keys are refreshed at this interval.'));
		o.datatype = 'uinteger';
		o.default = '300';
		o.placeholder = '300';
		o.depends('type', 'openrouter');
		o.depends('type', 'deepinfra');

		// Expiration interval (OpenRouter, DeepInfra)
		o = s.option(form.Value, 'expires_interval', _('Expiration Interval'),
			_('Credential expiration in seconds. Must be greater than rotation interval.'));
		o.datatype = 'uinteger';
		o.default = '600';
		o.placeholder = '600';
		o.depends('type', 'openrouter');
		o.depends('type', 'deepinfra');

		// Custom validation: expiration must be > rotation
		o.validate = function(section_id, value) {
			var rotation = uci.get('saturn', section_id, 'rotation_interval');
			if (rotation && value) {
				var rot_val = parseInt(rotation, 10);
				var exp_val = parseInt(value, 10);
				if (exp_val <= rot_val) {
					return _('Expiration interval must be greater than rotation interval (%d seconds)').format(rot_val);
				}
			}
			return true;
		};

		// --- Network service fields ---

		// Host (for network services)
		o = s.option(form.Value, 'host', _('Host'),
			_('Hostname or IP address where the service is running.'));
		o.datatype = 'host';
		o.placeholder = '192.168.1.50';
		o.depends('type', 'ollama');
		o.depends('type', 'vllm');
		o.depends('type', 'localai');
		o.depends('type', 'custom');

		// Port (for network services)
		o = s.option(form.Value, 'port', _('Port'),
			_('Port number for the service.'));
		o.datatype = 'port';
		o.depends('type', 'ollama');
		o.depends('type', 'vllm');
		o.depends('type', 'localai');
		o.depends('type', 'custom');

		// Set default ports based on type
		o.cfgvalue = function(section_id) {
			var val = uci.get('saturn', section_id, 'port');
			if (val) return val;
			var type = uci.get('saturn', section_id, 'type');
			switch(type) {
				case 'ollama': return '11434';
				case 'vllm': return '8000';
				case 'localai': return '8080';
				default: return '';
			}
		};

		// Endpoint path (custom only)
		o = s.option(form.Value, 'endpoint_path', _('Endpoint Path'),
			_('Custom API base path (e.g., /v1). Health checks will append /health.'));
		o.default = '/v1';
		o.placeholder = '/v1';
		o.depends('type', 'custom');

		// Test Connection button (for network services)
		o = s.option(form.Button, '_test_connection', _('Test Connection'));
		o.inputtitle = _('Test');
		o.inputstyle = 'action';
		o.depends('type', 'ollama');
		o.depends('type', 'vllm');
		o.depends('type', 'localai');
		o.depends('type', 'custom');

		o.onclick = function(ev, section_id) {
			var svc_type = uci.get('saturn', section_id, 'type');
			var host = uci.get('saturn', section_id, 'host');
			var port = uci.get('saturn', section_id, 'port');
			var endpoint_path = uci.get('saturn', section_id, 'endpoint_path') || '/v1';

			// Use defaults if port not set
			if (!port) {
				switch(svc_type) {
					case 'ollama': port = '11434'; break;
					case 'vllm': port = '8000'; break;
					case 'localai': port = '8080'; break;
					default: port = '8080';
				}
			}

			if (!host) {
				ui.addNotification(null, E('p', _('Please enter a host address first.')), 'warning');
				return;
			}

			var btn = ev.target;
			btn.disabled = true;
			btn.value = _('Testing...');

			return callTestConnection(svc_type, host, port, endpoint_path).then(function(result) {
				btn.disabled = false;
				btn.value = _('Test');

				if (result.success) {
					ui.addNotification(null, E('p', [
						E('strong', _('Success: ')),
						result.message || _('Connection successful')
					]), 'info');
				} else {
					ui.addNotification(null, E('p', [
						E('strong', _('Failed: ')),
						result.error || _('Connection failed')
					]), 'warning');
				}
			}).catch(function(err) {
				btn.disabled = false;
				btn.value = _('Test');
				ui.addNotification(null, E('p', [
					E('strong', _('Error: ')),
					err.message || _('RPC call failed')
				]), 'error');
			});
		};

		// Start polling for status updates
		poll.add(updateStatusIndicators, 10);

		return m.render().then(function(mapEl) {
			// Insert service control section after the first cbi-section (Global Settings)
			var sections = mapEl.querySelectorAll('.cbi-section');
			if (sections.length > 0) {
				sections[0].parentNode.insertBefore(serviceControlHtml, sections[0].nextSibling);
			} else {
				mapEl.insertBefore(serviceControlHtml, mapEl.firstChild);
			}

			var uninstallSection = E('div', { 'class': 'cbi-section', 'style': 'margin-top: 2em; padding-top: 1em; border-top: 1px solid #ddd;' }, [
				E('h3', {}, _('Uninstall Saturn')),
				E('p', { 'style': 'color: #666;' }, 
					_('Remove Saturn and all its configuration from this device.')),
				E('button', {
					'class': 'btn cbi-button',
					'style': 'background-color:#dc3545;color:white;border-color:#dc3545;',
					'click': function(ev) {
						if (!confirm(_('This will remove Saturn and all configurations. Continue?'))) {
							return;
						}
						var btn = ev.target;
						btn.disabled = true;
						btn.textContent = _('Uninstalling...');
						
						callUninstall().then(function(result) {
							if (result.success) {
								ui.addNotification(null, E('p', _('Saturn has been uninstalled. Redirecting to home page...')), 'info');
								setTimeout(function() {
									window.location.href = '/cgi-bin/luci/';
								}, 2000);
							} else {
								btn.disabled = false;
								btn.textContent = _('Uninstall Saturn');
								ui.addNotification(null, E('p', [
									E('strong', _('Error: ')),
									result.error || _('Uninstall failed')
								]), 'error');
							}
						}).catch(function(err) {
							btn.disabled = false;
							btn.textContent = _('Uninstall Saturn');
							ui.addNotification(null, E('p', [
								E('strong', _('Error: ')),
								err.message || _('RPC call failed')
							]), 'error');
						});
					}
				}, _('Uninstall Saturn'))
			]);
			
			mapEl.appendChild(uninstallSection);
			return mapEl;
		});
	}
});
