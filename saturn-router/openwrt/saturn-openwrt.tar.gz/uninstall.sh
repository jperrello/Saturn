#!/bin/sh
# Saturn Uninstaller - runs on OpenWRT router

echo "=== Uninstalling Saturn ==="

/etc/init.d/saturn stop 2>/dev/null || true
/etc/init.d/saturn disable 2>/dev/null || true

rm -f /usr/bin/saturn
rm -f /etc/init.d/saturn
rm -rf /tmp/saturn
rm -rf /www/luci-static/resources/view/saturn
rm -f /usr/share/luci/menu.d/luci-app-saturn.json
rm -f /usr/share/rpcd/acl.d/luci-app-saturn.json
rm -f /usr/libexec/rpcd/luci.saturn

# Keep config for reinstall? Ask user
echo ""
read -p "Remove /etc/config/saturn? [y/N] " answer
case "$answer" in
    [Yy]*) rm -f /etc/config/saturn; echo "Config removed" ;;
    *) echo "Config kept at /etc/config/saturn" ;;
esac

/etc/init.d/rpcd restart

echo ""
echo "=== Uninstall Complete ==="
