#!/bin/sh
# Saturn Installer - runs on OpenWRT router

set -e

echo "=== Installing Saturn ==="

# Check we're on OpenWRT
if [ ! -f /etc/openwrt_release ]; then
    echo "Error: This doesn't look like an OpenWRT system"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Install binary
echo "[1/5] Installing saturn..."
cp saturn /usr/bin/
chmod +x /usr/bin/saturn

# Install config (don't overwrite existing)
echo "[2/5] Installing config files..."
if [ ! -f /etc/config/saturn ]; then
    cp etc/config/saturn /etc/config/
    echo "      Created /etc/config/saturn"
else
    echo "      /etc/config/saturn exists, keeping current config"
fi

cp etc/init.d/saturn /etc/init.d/
chmod +x /etc/init.d/saturn

# Install uninstall script
echo "[3/6] Installing uninstall script..."
cp usr/bin/saturn-uninstall /usr/bin/
chmod +x /usr/bin/saturn-uninstall

# Install LuCI app
echo "[4/6] Installing LuCI web interface..."
mkdir -p /www/luci-static/resources/view/saturn
mkdir -p /usr/share/luci/menu.d
mkdir -p /usr/share/rpcd/acl.d
mkdir -p /usr/libexec/rpcd

cp www/luci-static/resources/view/saturn/services.js /www/luci-static/resources/view/saturn/
cp usr/share/luci/menu.d/luci-app-saturn.json /usr/share/luci/menu.d/
cp usr/share/rpcd/acl.d/luci-app-saturn.json /usr/share/rpcd/acl.d/
cp usr/libexec/rpcd/luci.saturn /usr/libexec/rpcd/
chmod +x /usr/libexec/rpcd/luci.saturn

# Enable and restart services
echo "[5/6] Enabling saturn service..."
/etc/init.d/saturn enable

echo "[6/6] Restarting services..."
/etc/init.d/rpcd restart

echo ""
echo "=== Installation Complete ==="
echo ""
echo "Open your router's web interface and go to:"
echo "  Services > Saturn"
echo ""
echo "To start Saturn now:"
echo "  /etc/init.d/saturn start"
echo ""
echo "To view logs:"
echo "  logread | grep saturn"
